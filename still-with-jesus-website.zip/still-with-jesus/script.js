'use strict';

const API = 'https://bible.helloao.org/api';
const $ = (id) => document.getElementById(id);

const els = {
  visitorName: $('visitorName'), verseDate: $('verseDate'), languageSelect: $('languageSelect'),
  translationSelect: $('translationSelect'), getVerseBtn: $('getVerseBtn'), sourceStatus: $('sourceStatus'),
  dailyResult: $('dailyResult'), greetingText: $('greetingText'), verseText: $('verseText'),
  verseReference: $('verseReference'), licenseNotice: $('licenseNotice'), readVerseBtn: $('readVerseBtn'),
  explainBtn: $('explainBtn'), stopSpeechBtn: $('stopSpeechBtn'), explanationBox: $('explanationBox'),
  explanationText: $('explanationText'), readExplanationBtn: $('readExplanationBtn'), bookSelect: $('bookSelect'),
  chapterSelect: $('chapterSelect'), loadChapterBtn: $('loadChapterBtn'), chapterToolbar: $('chapterToolbar'),
  chapterHeading: $('chapterHeading'), readChapterBtn: $('readChapterBtn'), chapterContent: $('chapterContent'), toast: $('toast')
};

// A curated group of comforting passages. The selected verse changes by name + date.
const DAILY_REFERENCES = [
  ['PSA', 23, 1], ['PSA', 46, 1], ['PSA', 34, 18], ['PSA', 55, 22], ['PSA', 121, 1],
  ['PSA', 37, 5], ['PSA', 119, 105], ['PSA', 27, 1], ['ISA', 41, 10], ['ISA', 40, 31],
  ['ISA', 43, 2], ['JER', 29, 11], ['MAT', 11, 28], ['MAT', 6, 34], ['MAT', 5, 9],
  ['MAT', 6, 33], ['JHN', 3, 16], ['JHN', 14, 27], ['JHN', 15, 5], ['ROM', 8, 28],
  ['ROM', 12, 12], ['PHP', 4, 6], ['PHP', 4, 7], ['PHP', 4, 13], ['PHP', 4, 19],
  ['1PE', 5, 7], ['PRO', 3, 5], ['PRO', 16, 3], ['HEB', 11, 1], ['JOS', 1, 9],
  ['2CO', 12, 9], ['LAM', 3, 22], ['1JN', 4, 18], ['GAL', 6, 9], ['EPH', 2, 10],
  ['DEU', 31, 6], ['EXO', 14, 14], ['PSA', 91, 1], ['PSA', 16, 8], ['PSA', 30, 5],
  ['ROM', 15, 13], ['MAT', 19, 26], ['ISA', 26, 3], ['JHN', 16, 33], ['PSA', 139, 14]
];

// Original, plain-language Tamil explanations for the daily passages above.
const TAMIL_EXPLANATIONS = {
  'PSA 23:1': 'இந்த வசனம் நமக்கு ஒரு நம்பிக்கையைத் தருகிறது. ஒரு நல்ல மேய்ப்பன் தன் ஆடுகளைப் பாதுகாப்பது போல, கடவுள் நம்மைப் பார்த்துக்கொள்கிறார். நமக்குத் தேவையானதை அவர் அறிந்திருக்கிறார். அதனால் நாளையை நினைத்து பயப்படாமல் அவரை நம்பலாம்.',
  'PSA 46:1': 'வாழ்க்கையில் பிரச்சினைகள் வந்தாலும் நாம் தனியாக இல்லை. கஷ்டமான நேரத்தில் கடவுள் நமக்கு உதவவும், நம்மைத் தாங்கவும் இருக்கிறார். பயப்படாமல் அவரிடம் நம்பிக்கையோடு செல்லலாம்.',
  'PSA 34:18': 'நம் மனம் உடைந்து போகும் நேரங்களிலும் கடவுள் நமக்கு அருகில்தான் இருக்கிறார். நம்முடைய கண்ணீரையும் வலியையும் அவர் கவனிக்கிறார். மனம் சோர்ந்துவிட்டால் அவரிடம் மனம் திறந்து பேசலாம்.',
  'PSA 55:22': 'நம்மால் சமாளிக்க முடியாத கவலைகளை எல்லாம் தனியாகச் சுமக்க வேண்டியதில்லை. அவற்றை கடவுளிடம் ஒப்படைக்கலாம். அவர் நம்மைத் தாங்குவார் என்ற நம்பிக்கையோடு ஒவ்வொரு நாளையும் எதிர்கொள்ளலாம்.',
  'PSA 121:1': 'உதவி எங்கிருந்து வரும் என்று தெரியாமல் இருக்கலாம். ஆனால் நம் நம்பிக்கை கடவுள்மேல் இருக்கும்போது, அவர் நமக்கு வழிகாட்டுவார். சிக்கலில் இருக்கும்போது அவரை நோக்கிப் பாருங்கள்.',
  'PSA 37:5': 'நம் வாழ்க்கைத் திட்டங்களையும் முடிவுகளையும் கடவுளிடம் ஒப்படைக்க வேண்டும். நம்மால் முடிந்ததை நேர்மையாகச் செய்து, மீதியை அவருடைய வழிநடத்துதலுக்கு நம்பிக்கையோடு விட்டுவிடலாம்.',
  'PSA 119:105': 'இருட்டில் ஒரு விளக்கு வழியைக் காட்டுவது போல, கடவுளுடைய வார்த்தை நாம் சரியான முடிவுகளை எடுக்க உதவுகிறது. குழப்பமாக இருக்கும்போது அதைப் படித்து வழிகாட்டுதலைப் பெறலாம்.',
  'PSA 27:1': 'கடவுள் நமக்கு வெளிச்சமும் பாதுகாப்பும் என்பதால் பயம் நம்மை ஆட்கொள்ள வேண்டியதில்லை. பிரச்சினைகள் இருந்தாலும் தைரியமாக இருக்கலாம்; அவர் நம்முடன் இருக்கிறார்.',
  'ISA 41:10': 'நீ பயப்பட வேண்டாம் என்று கடவுள் உறுதி கொடுக்கிறார். பலவீனமாக உணரும்போது அவர் உனக்கு பலம் தருவார்; கஷ்டத்தில் கைவிடமாட்டார். நீ தனியாக இல்லை என்பதை நினைவில் வைத்துக்கொள்.',
  'ISA 40:31': 'காத்திருப்பது சில நேரங்களில் கடினமாக இருக்கும். ஆனாலும் நம்பிக்கையோடு கடவுளைச் சார்ந்திருப்பவர்களுக்கு மீண்டும் உற்சாகமும் பலமும் கிடைக்கும். அவசரப்படாமல் தொடர்ந்து முன்னேறலாம்.',
  'ISA 43:2': 'வாழ்க்கையில் கடினமான சூழ்நிலைகள் வந்தாலும் கடவுள் நம்மைக் கைவிடமாட்டார் என்பதே இந்த வசனத்தின் நம்பிக்கை. பிரச்சினை நம்மை மூழ்கடிக்காது; அவர் நம்முடன் நடப்பார்.',
  'JER 29:11': 'நம் எதிர்காலம் எப்படி இருக்கும் என்று தெரியாமல் கவலைப்படலாம். ஆனால் கடவுள் நமக்காக நன்மையை விரும்புகிறார் என்ற நம்பிக்கையை இந்த வசனம் நினைவூட்டுகிறது. நம்பிக்கையை இழக்காமல் தொடருங்கள்.',
  'MAT 11:28': 'மன அழுத்தம், சோர்வு, கவலை எல்லாம் அதிகமாக இருக்கும்போது இயேசுவிடம் வரலாம். எல்லாவற்றையும் உள்ளுக்குள் அடக்கிக்கொள்ள வேண்டியதில்லை. அவரிடம் ஓய்வையும் ஆறுதலையும் தேடலாம்.',
  'MAT 6:34': 'நாளை என்ன நடக்கும் என்று இன்றே அதிகமாகக் கவலைப்பட வேண்டாம். இன்று செய்ய வேண்டியதை கவனமாகச் செய்யுங்கள். ஒவ்வொரு நாளுக்கும் தேவையான உதவியை கடவுள் தருவார் என்று நம்புங்கள்.',
  'MAT 5:9': 'சண்டையை வளர்ப்பதற்குப் பதிலாக சமாதானத்தை உருவாக்குகிறவர்கள் கடவுளுக்கு மகிழ்ச்சி தருகிறார்கள். நம் பேச்சிலும் செயலிலும் அமைதியையும் அன்பையும் காட்ட முயற்சி செய்ய வேண்டும்.',
  'MAT 6:33': 'பணம், வேலை, எதிர்காலம் என்று பல விஷயங்கள் முக்கியமாகத் தோன்றலாம். ஆனால் முதலில் கடவுளுடைய விருப்பத்தையும் நல்ல வழியையும் தேடுங்கள். மற்ற தேவைகளையும் அவர் கவனிப்பார் என்று நம்புங்கள்.',
  'JHN 3:16': 'கடவுள் மனிதர்களை எவ்வளவு நேசிக்கிறார் என்பதை இந்த வசனம் சொல்கிறது. அந்த அன்பை வெளிப்படுத்தவே இயேசுவை அனுப்பினார். இயேசுவை நம்புகிறவர்களுக்கு நித்திய வாழ்வின் நம்பிக்கை இருக்கிறது.',
  'JHN 14:27': 'உலகம் தரும் அமைதி சூழ்நிலை மாறினால் மறைந்துவிடலாம். இயேசு தரும் சமாதானம் அதைவிட ஆழமானது. குழப்பம் இருந்தாலும் மனதை அவரிடம் ஒப்படைத்து அமைதியைப் பெறலாம்.',
  'JHN 15:5': 'ஒரு கிளை மரத்துடன் இணைந்திருந்தால்தான் கனி தரும். அதுபோல இயேசுவுடன் நெருக்கமாக இருந்து, அவருடைய வார்த்தையைப் பின்பற்றினால் நம் வாழ்க்கையில் நல்ல மாற்றம் உருவாகும்.',
  'ROM 8:28': 'நமக்கு நடக்கும் எல்லாமே உடனே நல்லதாகத் தெரியாது. ஆனாலும் கடவுளை நேசித்து அவருடைய வழியில் நடப்பவர்களின் வாழ்க்கையில், கடினமான அனுபவங்களையும் அவர் நன்மைக்காகப் பயன்படுத்த முடியும்.',
  'ROM 12:12': 'நம்பிக்கையோடு மகிழ்ச்சியாக இருங்கள்; கஷ்டம் வந்தால் பொறுமையாக இருங்கள்; தொடர்ந்து ஜெபியுங்கள். இந்த மூன்று விஷயங்களும் கடினமான நாட்களில் மனதை உறுதியாக வைத்திருக்க உதவும்.',
  'PHP 4:6': 'எல்லாவற்றையும் நினைத்து பதற்றப்படாமல், உன் தேவைகளையும் கவலைகளையும் ஜெபத்தில் கடவுளிடம் சொல்லு. நன்றி சொல்லவும் மறக்காதே. மனதில் இருப்பதை அவரிடம் நேர்மையாகப் பகிரலாம்.',
  'PHP 4:7': 'கடவுள் தரும் சமாதானம் எல்லா பிரச்சினைகளும் உடனே மறைந்துவிடும் என்று அர்த்தமில்லை. ஆனால் பிரச்சினைகளுக்கு நடுவிலும் நம் மனதையும் எண்ணங்களையும் அவர் காக்க முடியும்.',
  'PHP 4:13': 'கடவுள் தரும் பலத்தால் கடினமான சூழ்நிலைகளையும் எதிர்கொள்ள முடியும். இதன் பொருள் எல்லாவற்றையும் நம் விருப்பப்படி பெறுவோம் என்பதல்ல; எந்த நிலையிலும் உறுதியாக இருக்க அவர் உதவுவார் என்பதே.',
  'PHP 4:19': 'நம் தேவைகளை கடவுள் அறிந்திருக்கிறார். நமக்கு உண்மையாகத் தேவையானதை அவர் தமது வழியில் தருவார் என்று நம்பலாம். நன்றி உள்ள மனதுடன் அவரைச் சார்ந்து வாழுங்கள்.',
  '1PE 5:7': 'உன் மனதில் இருக்கும் கவலைகளை மறைத்து வைத்துக்கொள்ள வேண்டாம். கடவுள் உன்னை அக்கறையோடு கவனிக்கிறார். அதனால் உன் பாரத்தையெல்லாம் அவரிடம் ஒப்படைக்கலாம்.',
  'PRO 3:5': 'நமக்குத் தெரிந்தது மட்டுமே முழு உண்மை என்று நினைக்காமல் கடவுளை முழுமையாக நம்ப வேண்டும். முடிவெடுக்கும் முன் அவருடைய வழிகாட்டுதலை நாடுங்கள்.',
  'PRO 16:3': 'நீ செய்யும் வேலைகளையும் திட்டங்களையும் கடவுளிடம் ஒப்படைத்து, நேர்மையாக உழை. உன் எண்ணங்களும் முடிவுகளும் தெளிவாக அமைய அவரிடம் உதவி கேள்.',
  'HEB 11:1': 'நாம் இன்னும் பார்க்காத நல்லதையும், உடனே கையில் கிடைக்காத வாக்குறுதியையும் நம்பிக்கையோடு எதிர்பார்ப்பதே விசுவாசம். சூழ்நிலை புரியாவிட்டாலும் கடவுளை நம்பி நடப்பது முக்கியம்.',
  'JOS 1:9': 'தைரியமாகவும் உறுதியாகவும் இரு என்று கடவுள் சொல்கிறார். புதிய பொறுப்பு அல்லது தெரியாத பாதை வந்தாலும் பயப்படாதே. நீ செல்லும் இடமெல்லாம் அவர் உன்னுடன் இருப்பார்.',
  '2CO 12:9': 'நாம் பலவீனமாக இருக்கும் நேரத்திலும் கடவுளுடைய கிருபை போதுமானது. எல்லாவற்றையும் தனியாகச் செய்ய வேண்டும் என்று நினைக்காதே. உன் குறைகளை அவரிடம் சொல்லி அவருடைய பலத்தை நம்பு.',
  'LAM 3:22': 'நாம் இன்னும் நம்பிக்கையோடு வாழ்வதற்குக் காரணம் கடவுளுடைய இரக்கமும் அன்பும். நேற்று தவறு செய்திருந்தாலும், இன்று அவரிடம் திரும்பி புதிய தொடக்கத்தைச் செய்யலாம்.',
  '1JN 4:18': 'உண்மையான அன்பு பயத்தை மெதுவாக அகற்றுகிறது. கடவுள் நம்மை அன்போடு ஏற்றுக்கொள்கிறார் என்பதைப் புரிந்துகொள்ளும்போது, தண்டனை பற்றிய பயத்தில் அல்ல, நம்பிக்கையில் வாழ முடியும்.',
  'GAL 6:9': 'நல்லதைச் செய்வது சில நேரங்களில் சோர்வாக இருக்கலாம்; உடனே பலன் தெரியாமல் போகலாம். இருந்தாலும் நன்மை செய்வதை நிறுத்தாதீர்கள். சரியான நேரத்தில் அதன் பலனைப் பெறுவீர்கள்.',
  'EPH 2:10': 'நீ பயனற்றவர் அல்ல. கடவுள் உன்னை நோக்கத்தோடு உருவாக்கியிருக்கிறார். அன்பு, உதவி, நேர்மை போன்ற நல்ல செயல்கள் மூலம் அந்த நோக்கத்தை வாழ்க்கையில் காட்டலாம்.',
  'DEU 31:6': 'தைரியமாக இருங்கள்; கடவுள் உங்களை ஒருபோதும் கைவிடமாட்டார். மனிதர்கள் விலகினாலும் அவர் உண்மையுள்ளவர். அதனால் பயத்தை விட நம்பிக்கையோடு முன்னேறுங்கள்.',
  'EXO 14:14': 'சில நேரங்களில் எதையும் செய்ய முடியாத அளவுக்கு சூழ்நிலை கடினமாக இருக்கும். அப்போது அவசரமாகத் தவறான முடிவு எடுக்காமல், அமைதியாக இருந்து கடவுளுடைய உதவியை நம்புங்கள்.',
  'PSA 91:1': 'கடவுளுடன் நெருக்கமாக வாழ்ந்து அவரை நம்புகிறவர்களுக்கு அவர் பாதுகாப்பான அடைக்கலமாக இருக்கிறார். பயம் வரும்போது அவருடைய அன்பையும் பாதுகாப்பையும் நினைத்துப் பாருங்கள்.',
  'PSA 16:8': 'உன் கவனத்தை எப்போதும் கடவுள்மேல் வைத்திருந்தால் மனம் உறுதியாக இருக்கும். சூழ்நிலை மாறினாலும் அவர் அருகில் இருக்கிறார் என்ற உண்மை உனக்கு தைரியம் தரும்.',
  'PSA 30:5': 'துக்கம் நிரந்தரமானது அல்ல. கடினமான இரவுக்குப் பிறகு காலை வருவது போல, வாழ்க்கையிலும் மீண்டும் மகிழ்ச்சி வரும். நம்பிக்கையை இழக்காமல் இருங்கள்.',
  'ROM 15:13': 'நம்பிக்கையின் கடவுள் உன் மனதை மகிழ்ச்சியாலும் சமாதானத்தாலும் நிரப்ப வேண்டும் என்பதே இந்த வாழ்த்து. எதிர்காலம் பற்றி பயப்படாமல், நம்பிக்கையோடு வாழலாம்.',
  'MAT 19:26': 'மனிதர்களால் முடியாத சில விஷயங்கள் இருக்கலாம். ஆனால் கடவுளுக்கு முடியாதது இல்லை என்று இயேசு நினைவூட்டுகிறார். நம்பிக்கையை இழக்காமல் அவரிடம் உதவி கேளுங்கள்.',
  'ISA 26:3': 'எண்ணங்கள் எல்லாம் கவலையில் சிக்கிக்கொள்ளும்போது, கடவுள்மேல் மனதை நிலைநிறுத்துங்கள். அவரை நம்புவது உள்ளுக்குள் ஆழமான அமைதியைத் தரும்.',
  'JHN 16:33': 'வாழ்க்கையில் பிரச்சினைகள் வரும் என்பதை இயேசு மறைக்கவில்லை. ஆனாலும் அவர் தரும் நம்பிக்கையால் தைரியமாக இருக்கலாம். கஷ்டம் கடைசி முடிவு அல்ல.',
  'PSA 139:14': 'நீ ஒரு மதிப்புள்ள படைப்பு. உன்னை மற்றவர்களுடன் ஒப்பிட்டு குறைவாக நினைக்க வேண்டாம். கடவுள் உன்னை தனித்துவமாக உருவாக்கியிருக்கிறார் என்பதை நினைவில் கொள்.'
};

let translations = [];
let currentVerse = null;
let currentExplanation = '';
let currentChapterVerses = [];
let currentBook = null;
let currentTranslation = null;
let speechUtterance = null;
let chapterCache = new Map();
let bookListCache = new Map();
let toastTimer = null;

function localDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.remove('show'), 3400);
}

async function fetchJson(url) {
  // Give slow connections a clear error instead of leaving the page stuck.
  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timeoutId = controller ? setTimeout(() => controller.abort(), 20000) : null;
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller ? controller.signal : undefined
    });
    if (!response.ok) {
      throw new Error(`Bible API returned HTTP ${response.status} for ${url}`);
    }
    const data = await response.json();
    if (!data || typeof data !== 'object') {
      throw new Error(`Invalid JSON response from ${url}`);
    }
    return data;
  } catch (error) {
    if (error && error.name === 'AbortError') {
      throw new Error('The Bible API request timed out. Please try again.');
    }
    throw error;
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

function getTranslationId(translation) { return translation.id || translation.translationId; }
function getTranslationLanguage(translation) { return translation.language || ''; }
function getTranslationLabel(translation) {
  const language = translation.languageName || translation.languageEnglishName || translation.language || 'Unknown language';
  const name = translation.name || translation.englishName || translation.shortName || getTranslationId(translation);
  return `${language} — ${name}`;
}

function populateLanguages(preferredLanguage) {
  const languageMap = new Map();
  translations.forEach((translation) => {
    const code = getTranslationLanguage(translation);
    if (!code) return;
    const label = translation.languageName || translation.languageEnglishName || code;
    if (!languageMap.has(code)) languageMap.set(code, label);
  });
  const languages = [...languageMap.entries()].sort((a, b) => a[1].localeCompare(b[1]));
  els.languageSelect.innerHTML = '';
  languages.forEach(([code, label]) => {
    const option = document.createElement('option');
    option.value = code;
    option.textContent = `${label} (${code})`;
    els.languageSelect.appendChild(option);
  });
  const initial = languages.some(([code]) => code === preferredLanguage) ? preferredLanguage
    : (languages.some(([code]) => code === 'eng') ? 'eng' : languages[0]?.[0]);
  if (initial) els.languageSelect.value = initial;
  els.languageSelect.disabled = false;
  populateTranslations();
}

function populateTranslations() {
  const language = els.languageSelect.value;
  const filtered = translations.filter((translation) => getTranslationLanguage(translation) === language)
    .sort((a, b) => getTranslationLabel(a).localeCompare(getTranslationLabel(b)));
  els.translationSelect.innerHTML = '';
  filtered.forEach((translation) => {
    const option = document.createElement('option');
    option.value = getTranslationId(translation);
    option.textContent = `${translation.name || translation.englishName || option.value} (${translation.shortName || option.value})`;
    els.translationSelect.appendChild(option);
  });
  els.translationSelect.disabled = filtered.length === 0;
  if (!filtered.length) {
    els.translationSelect.innerHTML = '<option value="">No translations listed</option>';
    els.getVerseBtn.disabled = true;
    els.sourceStatus.textContent = 'No translation is currently listed for this language.';
    return;
  }
  // Prefer a clear/default edition when the chosen language has one.
  const preferred = filtered.find((t) => ['BSB', 'engwebp', 'KJV'].includes(getTranslationId(t))) || filtered[0];
  els.translationSelect.value = getTranslationId(preferred);
  els.getVerseBtn.disabled = false;
  els.sourceStatus.textContent = `${filtered.length} translation(s) listed for this language. Bible text loads from the online library.`;
  currentTranslation = preferred;
  loadBooksForTranslation().catch((error) => console.warn('Could not load books:', error));
}

function hashString(value) {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function referenceLabel(book, chapter, verse) { return `${book} ${chapter}:${verse}`; }

async function getBooksForTranslation(translationId) {
  if (bookListCache.has(translationId)) return bookListCache.get(translationId);
  const data = await fetchJson(`${API}/${encodeURIComponent(translationId)}/books.json`);
  const books = data.books || [];
  bookListCache.set(translationId, books);
  return books;
}

async function fetchChapter(translationId, bookId, chapterNumber) {
  const key = `${translationId}/${bookId}/${chapterNumber}`;
  if (chapterCache.has(key)) return chapterCache.get(key);
  const data = await fetchJson(`${API}/${encodeURIComponent(translationId)}/${encodeURIComponent(bookId)}/${chapterNumber}.simple.json`);
  const verses = (data.chapter?.content || []).filter((item) => item.type === 'verse');
  const chapter = { data, verses };
  chapterCache.set(key, chapter);
  return chapter;
}

async function getDailyVerse() {
  const name = els.visitorName.value.trim();
  const date = els.verseDate.value;
  const translationId = els.translationSelect.value;
  if (!name) { showToast('Please enter your name first.'); els.visitorName.focus(); return; }
  if (!date) { showToast('Please choose a date.'); els.verseDate.focus(); return; }
  if (!translationId) { showToast('Please choose a Bible translation.'); return; }

  els.getVerseBtn.disabled = true;
  els.getVerseBtn.textContent = 'Finding your verse…';
  els.sourceStatus.textContent = 'Searching the selected Bible translation…';
  els.dailyResult.hidden = true;
  els.explanationBox.hidden = true;
  stopSpeech();

  try {
    const seed = hashString(`${name.toLocaleLowerCase()}|${date}`);
    const startIndex = seed % DAILY_REFERENCES.length;
    let found = null;
    let lastError = null;
    let availableBookIds = null;

    try {
      const books = await getBooksForTranslation(translationId);
      availableBookIds = new Set((books || []).map((book) => book.id));
    } catch (error) {
      lastError = error;
    }

    for (let offset = 0; offset < DAILY_REFERENCES.length; offset += 1) {
      const [bookId, chapterNumber, verseNumber] = DAILY_REFERENCES[(startIndex + offset) % DAILY_REFERENCES.length];
      if (availableBookIds && !availableBookIds.has(bookId)) continue;
      try {
        const chapter = await fetchChapter(translationId, bookId, chapterNumber);
        const verse = chapter.verses.find((item) => Number(item.number) === verseNumber);
        if (verse && verse.text) {
          const book = chapter.data.book?.commonName || chapter.data.book?.name || bookId;
          found = {
            text: verse.text,
            bookId,
            book,
            chapter: chapterNumber,
            verse: verseNumber,
            reference: referenceLabel(book, chapterNumber, verseNumber),
            translation: chapter.data.translation || currentTranslation,
            licenseNotice: chapter.data.translation?.licenseNotice || chapter.data.translation?.licenseNotes || ''
          };
          break;
        }
      } catch (error) {
        lastError = error;
      }
    }

    if (!found) {
      els.sourceStatus.textContent = 'Could not load a daily verse from this translation.';
      showToast(lastError
        ? 'The Bible service could not be reached. Check your internet connection and try again.'
        : 'No daily verse was found in this translation. Please choose another version.');
      return;
    }

    currentVerse = found;
    const displayDate = new Date(`${date}T12:00:00`).toLocaleDateString(undefined, {
      day: 'numeric', month: 'long', year: 'numeric'
    });
    els.greetingText.textContent = `For ${name} · ${displayDate}`;
    els.verseText.textContent = `“${found.text}”`;
    els.verseText.lang = found.translation?.language === 'tam' ? 'ta' : 'en';
    els.verseReference.textContent = `${found.reference} · ${found.translation?.name || translationId}`;
    els.licenseNotice.textContent = found.licenseNotice || '';
    els.dailyResult.hidden = false;
    currentExplanation = TAMIL_EXPLANATIONS[`${found.bookId} ${found.chapter}:${found.verse}`]
      || 'இந்த வசனம் கடவுளை நம்பிக்கையோடு சார்ந்து வாழ நம்மை நினைவூட்டுகிறது. இதை உங்கள் வாழ்க்கைச் சூழ்நிலையுடன் இணைத்துப் பாருங்கள். இந்த வார்த்தையை மட்டும் படித்துவிட்டு நிற்காமல், இன்று ஒரு நல்ல செயலாக மாற்ற முயற்சி செய்யுங்கள்.';
    els.sourceStatus.textContent = 'Your verse is ready. Take a quiet moment to read and reflect.';
    els.explainBtn.disabled = false;
  } catch (error) {
    console.error('Daily verse error:', error);
    els.sourceStatus.textContent = 'Something went wrong while loading the verse.';
    showToast(error?.message || 'Could not load the verse. Please refresh and try again.');
  } finally {
    els.getVerseBtn.disabled = false;
    els.getVerseBtn.innerHTML = 'Find my verse <span>→</span>';
  }
}

function getSpeechLanguage(langCode) {
  const map = { tam: 'ta-IN', eng: 'en-US', hin: 'hi-IN', tel: 'te-IN', kan: 'kn-IN', mal: 'ml-IN', ben: 'bn-IN', spa: 'es-ES', fra: 'fr-FR', deu: 'de-DE', por: 'pt-BR', ara: 'ar-SA', jpn: 'ja-JP', zho: 'zh-CN', kor: 'ko-KR', rus: 'ru-RU' };
  return map[langCode] || (langCode ? `${langCode}-IN` : 'en-US');
}

function findVoice(locale) {
  if (!('speechSynthesis' in window)) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices || !voices.length) return null;
  const normalized = String(locale || 'en-US').toLowerCase();
  const exact = voices.find((voice) => String(voice.lang).toLowerCase() === normalized);
  if (exact) return exact;
  const prefix = normalized.split('-')[0];
  return voices.find((voice) => String(voice.lang).toLowerCase().startsWith(`${prefix}-`)) || null;
}

function speakText(text, locale) {
  if (!('speechSynthesis' in window) || typeof window.SpeechSynthesisUtterance !== 'function') {
    showToast('Voice playback is not supported by this browser. Try the latest Chrome or Edge.');
    return;
  }
  if (!text) { showToast('There is no text to read yet.'); return; }
  stopSpeech();
  const utterance = new window.SpeechSynthesisUtterance(String(text));
  utterance.lang = locale || 'en-US';
  utterance.rate = 0.91;
  utterance.pitch = 1;
  const voice = findVoice(utterance.lang);
  if (voice) utterance.voice = voice;
  utterance.onstart = () => { els.stopSpeechBtn.disabled = false; };
  utterance.onend = () => { els.stopSpeechBtn.disabled = true; speechUtterance = null; };
  utterance.onerror = (event) => {
    els.stopSpeechBtn.disabled = true;
    speechUtterance = null;
    if (event.error !== 'canceled' && event.error !== 'interrupted') {
      showToast('Voice could not play. Check whether a Tamil voice is installed on your device.');
    }
  };
  speechUtterance = utterance;
  window.speechSynthesis.speak(utterance);
}

function stopSpeech() {
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  speechUtterance = null;
  els.stopSpeechBtn.disabled = true;
}

function explainVerse() {
  if (!currentVerse) { showToast('Find your daily verse first.'); return; }
  els.explanationText.textContent = currentExplanation;
  els.explanationBox.hidden = false;
  // The Explain button both reveals the meaning and starts its Tamil voice playback.
  speakText(currentExplanation, 'ta-IN');
}

async function loadBooksForTranslation() {
  const translationId = els.translationSelect.value;
  if (!translationId) return;
  els.bookSelect.disabled = true;
  els.bookSelect.innerHTML = '<option>Loading books…</option>';
  els.chapterSelect.disabled = true;
  els.loadChapterBtn.disabled = true;
  try {
    const books = await getBooksForTranslation(translationId);
    els.bookSelect.innerHTML = '';
    books.forEach((book) => {
      const option = document.createElement('option');
      option.value = book.id;
      option.textContent = book.commonName || book.name;
      option.dataset.chapters = String(book.numberOfChapters || 1);
      els.bookSelect.appendChild(option);
    });
    els.bookSelect.disabled = books.length === 0;
    els.bookSelect.dataset.translation = translationId;
    if (books.length) {
      populateChapters();
      els.loadChapterBtn.disabled = false;
    }
  } catch (error) {
    els.bookSelect.innerHTML = '<option value="">Could not load books</option>';
    showToast('Book list could not be loaded. Please try again.');
  }
}

function populateChapters() {
  const selected = els.bookSelect.selectedOptions[0];
  const total = Number(selected?.dataset.chapters || 1);
  els.chapterSelect.innerHTML = '';
  for (let number = 1; number <= total; number += 1) {
    const option = document.createElement('option');
    option.value = String(number);
    option.textContent = `Chapter ${number}`;
    els.chapterSelect.appendChild(option);
  }
  els.chapterSelect.disabled = false;
  els.loadChapterBtn.disabled = !selected;
}

async function loadSelectedChapter() {
  const translationId = els.translationSelect.value;
  const bookId = els.bookSelect.value;
  const chapterNumber = Number(els.chapterSelect.value);
  if (!translationId || !bookId || !chapterNumber) return;
  els.loadChapterBtn.disabled = true;
  els.loadChapterBtn.textContent = 'Opening…';
  try {
    const result = await fetchChapter(translationId, bookId, chapterNumber);
    currentChapterVerses = result.verses;
    currentBook = result.data.book;
    currentTranslation = result.data.translation;
    const bookName = currentBook?.commonName || currentBook?.name || bookId;
    els.chapterHeading.textContent = `${bookName} ${chapterNumber}`;
    els.chapterContent.innerHTML = '';
    result.verses.forEach((verse) => {
      const row = document.createElement('div');
      row.className = 'chapter-verse';
      const number = document.createElement('span');
      number.className = 'verse-number';
      number.textContent = verse.number;
      const text = document.createElement('p');
      text.className = 'verse-line';
      text.textContent = verse.text;
      text.lang = result.data.translation?.language === 'tam' ? 'ta' : (result.data.translation?.language || 'en');
      row.append(number, text);
      els.chapterContent.appendChild(row);
    });
    if (!result.verses.length) els.chapterContent.textContent = 'No verses were returned for this chapter.';
    els.chapterToolbar.hidden = false;
    els.chapterHeading.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (error) {
    showToast('Could not load this chapter. Try another chapter or translation.');
  } finally {
    els.loadChapterBtn.disabled = false;
    els.loadChapterBtn.innerHTML = 'Open chapter <span>→</span>';
  }
}

function listenToChapter() {
  if (!currentChapterVerses.length) { showToast('Open a chapter first.'); return; }
  const fullText = currentChapterVerses.map((verse) => `${verse.number}. ${verse.text}`).join(' ');
  const locale = getSpeechLanguage(currentTranslation?.language || 'eng');
  speakText(fullText, locale);
}

async function init() {
  els.verseDate.value = localDateString();
  els.getVerseBtn.disabled = true;
  try {
    const data = await fetchJson(`${API}/available_translations.json`);
    translations = (data.translations || []).filter((item) => item.id && item.language);
    if (!translations.length) throw new Error('No translations returned');
    // Tamil is the initial choice when the API currently lists a Tamil edition.
    const hasTamil = translations.some((item) => item.language === 'tam');
    populateLanguages(hasTamil ? 'tam' : 'eng');
    els.sourceStatus.textContent = `Connected · ${translations.length.toLocaleString()} Bible translation records are available.`;
    els.getVerseBtn.disabled = false;
  } catch (error) {
    els.sourceStatus.textContent = 'Could not connect to the Bible library. Check your internet connection and refresh.';
    els.languageSelect.innerHTML = '<option>Library unavailable</option>';
    showToast('Bible library connection failed.');
  }
}

els.languageSelect.addEventListener('change', populateTranslations);
els.translationSelect.addEventListener('change', () => {
  currentTranslation = translations.find((item) => getTranslationId(item) === els.translationSelect.value) || null;
  chapterCache.clear();
  loadBooksForTranslation();
  els.dailyResult.hidden = true;
  els.chapterToolbar.hidden = true;
  els.chapterContent.innerHTML = '<div class="empty-reading"><span>✧</span><p>Your reading space is ready.</p><small>Select a book and chapter to begin.</small></div>';
});
els.getVerseBtn.addEventListener('click', getDailyVerse);
els.readVerseBtn.addEventListener('click', () => {
  if (!currentVerse) return;
  const locale = getSpeechLanguage(currentVerse.translation?.language || 'eng');
  speakText(currentVerse.text, locale);
});
els.explainBtn.addEventListener('click', explainVerse);
els.readExplanationBtn.addEventListener('click', () => speakText(currentExplanation, 'ta-IN'));
els.stopSpeechBtn.addEventListener('click', stopSpeech);
els.bookSelect.addEventListener('change', populateChapters);
els.loadChapterBtn.addEventListener('click', loadSelectedChapter);
els.readChapterBtn.addEventListener('click', listenToChapter);

if ('speechSynthesis' in window) {
  // Browsers often populate their installed voices asynchronously.
  window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
}

// Make unexpected browser errors visible rather than silently breaking a button.
window.addEventListener('error', (event) => {
  console.error('Still With Jesus script error:', event.error || event.message);
});
window.addEventListener('unhandledrejection', (event) => {
  console.error('Still With Jesus async error:', event.reason);
});

init();
